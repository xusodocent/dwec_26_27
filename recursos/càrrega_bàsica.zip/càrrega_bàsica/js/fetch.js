async function carregar() {
  const eixida = document.querySelector('#resultat');
  try {
    const response = await fetch('./dades.json');
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const dades = await response.json();
    eixida.textContent = `${dades.nom}: ${dades.curs}`;
  } catch (error) {
    eixida.textContent = `Error: ${error.message}`;
  }
}
carregar();
