const eixida = document.querySelector('#resultat');
const xhr = new XMLHttpRequest();
xhr.open('GET', './dades.json');
xhr.responseType = 'json';
xhr.timeout = 10000;
xhr.onload = () => {
  if (xhr.status >= 200 && xhr.status < 300 && xhr.response) {
    eixida.textContent = `${xhr.response.nom}: ${xhr.response.curs}`;
  } else eixida.textContent = `Error HTTP o JSON incorrecte (${xhr.status})`;
};
xhr.onerror = () => { eixida.textContent = 'Error de xarxa'; };
xhr.ontimeout = () => { eixida.textContent = 'Temps d’espera excedit'; };
xhr.send();
