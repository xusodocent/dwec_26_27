import { createRouter, createWebHistory } from 'vue-router';
import { session, logout } from '../services/session.js';
import { currentUser } from '../services/api.js';
import CatalogView from '../views/CatalogView.vue';
import DetailView from '../views/DetailView.vue';
import EditorView from '../views/EditorView.vue';
import LoginView from '../views/LoginView.vue';
import AdminView from '../views/AdminView.vue';
import NotFoundView from '../views/NotFoundView.vue';
import ForbiddenView from '../views/ForbiddenView.vue';
const router = createRouter({ history: createWebHistory(import.meta.env.BASE_URL), routes: [
  { path: '/', redirect: '/reptes' },
  { path: '/reptes', component: CatalogView },
  { path: '/reptes/nou', component: EditorView, meta: { requiresAuth: true, roles: ['organitzador'] } },
  { path: '/reptes/:id', component: DetailView, props: true },
  { path: '/reptes/:id/editar', component: EditorView, props: true, meta: { requiresAuth: true, roles: ['organitzador'] } },
  { path: '/gestio', component: AdminView, meta: { requiresAuth: true, roles: ['organitzador'] } },
  { path: '/login', component: LoginView },
  { path: '/sense-permis', component: ForbiddenView },
  { path: '/:pathMatch(.*)*', component: NotFoundView },
] });
router.beforeEach(async to => {
  if (!to.meta.requiresAuth) return;
  if (!session.token) return { path: '/login', query: { redirect: to.fullPath } };
  try { await currentUser(); }
  catch (error) {
    if (error.status === 401 || error.status === 403) { logout(); return { path: '/login', query: { redirect: to.fullPath } }; }
    // Una fallada de xarxa cancel·la la navegació i mostra el problema.
    window.alert(error.message); return false;
  }
  if (to.meta.roles && !to.meta.roles.includes(session.user.rol)) return '/sense-permis';
});
export default router;
