<template><form @submit.prevent="enviar" novalidate>
  <label>Nom <input v-model.trim="form.nom" maxlength="80" :aria-invalid="!!errors.nom"></label><p role="alert">{{ errors.nom }}</p>
  <label>Categoria <select v-model="form.categoria"><option v-for="c in categories" :key="c">{{ c }}</option></select></label><p role="alert">{{ errors.categoria }}</p>
  <label>Minuts <input type="number" v-model.number="form.minuts"></label><p role="alert">{{ errors.minuts }}</p>
  <label>Punts <input type="number" v-model.number="form.punts"></label><p role="alert">{{ errors.punts }}</p>
  <label><input type="checkbox" v-model="form.actiu"> Actiu</label>
  <button :disabled="pendent">{{ pendent ? 'Guardant…' : 'Guarda' }}</button>
</form></template>
<script>
export default {
  props: { inicial: { type: Object, required: true }, pendent: Boolean }, emits: ['guardar'],
  data() { return { form: { ...this.inicial }, errors: {}, categories: ['logica','patrimoni','fotografia','esport'] }; },
  methods: { enviar() {
    if (this.pendent) return;
    const f = this.form, e = {};
    if (f.nom.length < 3 || f.nom.length > 80) e.nom = 'Entre 3 i 80 caràcters';
    if (!this.categories.includes(f.categoria)) e.categoria = 'Tria una categoria';
    if (!Number.isInteger(f.minuts) || f.minuts < 5 || f.minuts > 180) e.minuts = 'Enter entre 5 i 180';
    if (!Number.isInteger(f.punts) || f.punts < 0 || f.punts > 1000) e.punts = 'Enter entre 0 i 1000';
    this.errors = e;
    if (!Object.keys(e).length) this.$emit('guardar', { ...f });
  } }
};
</script>
