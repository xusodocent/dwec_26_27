<template><article>
  <h2>{{ repte.nom }}</h2><p>{{ repte.categoria }} · {{ repte.minuts }} min · {{ repte.punts }} punts</p>
  <p>{{ repte.actiu ? 'Actiu' : 'Inactiu' }}</p>
  <RouterLink :to="'/reptes/' + repte.id">Consulta el detall</RouterLink>
</article></template>
<script>
export default { props: { repte: { type: Object, required: true } } };
</script>
