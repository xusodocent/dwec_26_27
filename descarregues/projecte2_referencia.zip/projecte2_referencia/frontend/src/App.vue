<template>
  <header><h1>La Vall en Joc · Gestor de reptes</h1><nav>
    <RouterLink to="/reptes">Catàleg</RouterLink>
    <RouterLink v-if="session.user?.rol === 'organitzador'" to="/gestio">Gestió</RouterLink>
    <RouterLink v-if="!session.token" to="/login">Inicia sessió</RouterLink>
    <button v-else @click="eixir">Tanca sessió</button>
  </nav><p v-if="session.user">{{ session.user.email }} · {{ session.user.rol }}</p></header>
  <main><RouterView /></main>
</template>
<script>
import { session, logout } from './services/session.js';
export default { data: () => ({ session }), methods: {
  eixir() { logout(); this.$router.replace('/reptes'); }
} };
</script>
