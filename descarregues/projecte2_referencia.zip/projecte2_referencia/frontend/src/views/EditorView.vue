<template><h2>{{ id ? 'Edita el repte' : 'Nou repte' }}</h2>
  <p v-if="carregant" role="status">Carregant…</p>
  <p v-if="error" role="alert">{{ error }}</p>
  <ul v-if="Object.keys(errorsServidor).length"><li v-for="(text, camp) in errorsServidor" :key="camp">{{ camp }}: {{ text }}</li></ul>
  <RepteForm v-if="inicial && !carregant" :key="id || 'nou'" :inicial="inicial" :pendent="pendent" @guardar="guardar" />
</template>
<script>
import RepteForm from '../components/RepteForm.vue';
import { reptesApi } from '../services/api.js';
export default { components: { RepteForm }, props: { id: String },
  data: () => ({ inicial: null, error: '', errorsServidor: {}, carregant: false, pendent: false, peticio: 0 }),
  watch: { id: { immediate: true, handler: 'carregar' } },
  beforeUnmount() { this.peticio++; },
  methods: {
    async carregar() {
      const actual = ++this.peticio; this.carregant = true; this.error = ''; this.inicial = null; this.errorsServidor = {};
      try {
        const r = this.id ? await reptesApi.detail(this.id) : { nom: '', categoria: 'logica', minuts: 20, punts: 100, actiu: true };
        if (actual !== this.peticio) return;
        this.inicial = { nom: r.nom, categoria: r.categoria, minuts: r.minuts, punts: r.punts, actiu: r.actiu };
      } catch (e) { if (actual === this.peticio) this.error = e.message; }
      finally { if (actual === this.peticio) this.carregant = false; }
    },
    async guardar(body) {
      if (this.pendent) return;
      this.pendent = true; this.error = ''; this.errorsServidor = {};
      try {
        const r = this.id ? await reptesApi.replace(this.id, body) : await reptesApi.create(body);
        await this.$router.push('/reptes/' + r.id);
      } catch (e) { this.error = e.message; this.errorsServidor = e.fields || {};
        if (e.status === 401) await this.$router.push({ path: '/login', query: { redirect: this.$route.fullPath } }); }
      finally { this.pendent = false; }
    }
  }
};
</script>
