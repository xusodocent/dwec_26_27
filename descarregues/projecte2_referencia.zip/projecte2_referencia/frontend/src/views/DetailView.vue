<template>
  <p v-if="carregant" role="status">Carregant…</p>
  <p v-else-if="error" role="alert">{{ error }}</p>
  <article v-else-if="repte"><h2>{{ repte.nom }}</h2>
    <p>{{ repte.categoria }} · {{ repte.minuts }} min · {{ repte.punts }} punts</p>
    <p>{{ repte.actiu ? 'Actiu' : 'Inactiu' }}</p>
    <RouterLink v-if="session.user?.rol === 'organitzador'" :to="'/reptes/' + id + '/editar'">Edita</RouterLink>
  </article><RouterLink to="/reptes">Torna al catàleg</RouterLink>
</template>
<script>
import { reptesApi } from '../services/api.js';
import { session } from '../services/session.js';
export default { props: { id: String }, data: () => ({ session, repte: null, error: '', carregant: false, peticio: 0 }),
  watch: { id: { immediate: true, handler: 'carregar' } },
  beforeUnmount() { this.peticio++; },
  methods: { async carregar() {
    const actual = ++this.peticio; this.carregant = true; this.error = ''; this.repte = null;
    try { const result = await reptesApi.detail(this.id); if (actual === this.peticio) this.repte = result; }
    catch (e) { if (actual === this.peticio) this.error = e.status === 404 ? 'Aquest repte no existeix.' : e.message; }
    finally { if (actual === this.peticio) this.carregant = false; }
  } }
};
</script>
