<template><h2>Gestió</h2><RouterLink to="/reptes/nou">Crea un repte</RouterLink>
  <p v-if="carregant" role="status">Carregant…</p><p v-if="error" role="alert">{{ error }}</p>
  <button @click="carregar" :disabled="pendent || carregant">Actualitza la llista</button>
  <article v-for="r in reptes" :key="r.id"><h3>{{ r.nom }}</h3>
    <RouterLink :to="'/reptes/' + r.id + '/editar'">Edita</RouterLink>
    <button :disabled="pendent" @click="canviar(r)">{{ r.actiu ? 'Desactiva' : 'Activa' }}</button>
    <button :disabled="pendent" @click="eliminar(r)">Elimina</button>
  </article>
  <p>Pàgina {{ pagina }} · {{ total }} reptes</p>
  <button :disabled="pendent || carregant || pagina === 1" @click="pagina--; carregar()">Anterior</button>
  <button :disabled="pendent || carregant || pagina * 4 >= total" @click="pagina++; carregar()">Següent</button>
</template>
<script>
import { reptesApi } from '../services/api.js';
export default { data: () => ({ reptes: [], total: 0, pagina: 1, error: '', carregant: false, pendent: false, peticio: 0 }),
  mounted() { this.carregar(); }, beforeUnmount() { this.peticio++; }, methods: {
    async carregar() {
      const actual = ++this.peticio; this.carregant = true; this.error = '';
      try {
        let result = await reptesApi.list({ mida: 4, pagina: this.pagina });
        if (actual !== this.peticio) return;
        if (!result.dades.length && this.pagina > 1) { this.pagina--; result = await reptesApi.list({ mida: 4, pagina: this.pagina }); }
        if (actual === this.peticio) { this.reptes = result.dades; this.total = result.total; }
      } catch (e) { if (actual === this.peticio) this.error = e.message; }
      finally { if (actual === this.peticio) this.carregant = false; }
    },
    async executar(action) {
      if (this.pendent) return;
      this.pendent = true; this.error = '';
      try { await action(); await this.carregar(); }
      catch (e) { this.error = e.message; if (e.status === 401) await this.$router.push({ path: '/login', query: { redirect: '/gestio' } }); }
      finally { this.pendent = false; }
    },
    canviar(r) { this.executar(() => reptesApi.update(r.id, { actiu: !r.actiu })); },
    eliminar(r) { if (window.confirm('Vols eliminar ' + r.nom + '?')) this.executar(() => reptesApi.remove(r.id)); }
  }
};
</script>
