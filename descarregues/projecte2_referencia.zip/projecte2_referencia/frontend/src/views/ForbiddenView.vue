<template><h2>Accés no permés</h2><p>El teu rol no té accés a aquesta pàgina.</p><RouterLink to="/reptes">Torna al catàleg</RouterLink></template>
