<template>
  <h2>Catàleg</h2><form @submit.prevent="pagina = 1; carregar()">
    <label>Cerca <input v-model="q" maxlength="80"></label>
    <label>Categoria <select v-model="categoria"><option value="">Totes</option>
      <option v-for="c in categories" :key="c">{{ c }}</option></select></label>
    <label>Ordre <select v-model="ordre"><option value="nom">Nom</option><option value="minuts">Minuts</option></select></label>
    <button :disabled="carregant">Busca</button>
  </form>
  <p v-if="carregant" role="status">Carregant…</p>
  <p v-else-if="error" role="alert">{{ error }} <button @click="carregar">Reintenta</button></p>
  <template v-else>
    <p v-if="!reptes.length">No hi ha reptes amb aquests filtres.</p>
    <RepteCard v-for="r in reptes" :key="r.id" :repte="r" />
    <p>{{ total }} resultats · pàgina {{ pagina }}</p>
    <button :disabled="pagina === 1" @click="pagina--; carregar()">Anterior</button>
    <button :disabled="pagina * mida >= total" @click="pagina++; carregar()">Següent</button>
  </template>
</template>
<script>
import RepteCard from '../components/RepteCard.vue';
import { reptesApi } from '../services/api.js';
export default {
  components: { RepteCard },
  data: () => ({ reptes: [], q: '', categoria: '', ordre: 'nom', pagina: 1, mida: 4,
    total: 0, carregant: false, error: '', peticio: 0, categories: ['logica','patrimoni','fotografia','esport'] }),
  mounted() { this.carregar(); },
  beforeUnmount() { this.peticio++; },
  methods: { async carregar() {
    const actual = ++this.peticio;
    this.carregant = true; this.error = '';
    try {
      const result = await reptesApi.list({ q: this.q, categoria: this.categoria,
        ordre: this.ordre, pagina: this.pagina, mida: this.mida });
      if (actual !== this.peticio) return;
      this.reptes = result.dades; this.total = result.total;
    } catch (error) { if (actual === this.peticio) this.error = error.message; }
    finally { if (actual === this.peticio) this.carregant = false; }
  } }
};
</script>
