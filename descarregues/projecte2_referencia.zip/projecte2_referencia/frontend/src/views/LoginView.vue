<template><h2>Inicia sessió</h2><form @submit.prevent="entrar">
  <label>Correu <input type="email" v-model.trim="email" autocomplete="username" required></label>
  <label>Contrasenya <input type="password" v-model="password" autocomplete="current-password" required></label>
  <button :disabled="pendent">{{ pendent ? 'Comprovant…' : 'Entra' }}</button>
  <p v-if="error" role="alert">{{ error }}</p>
</form></template>
<script>
import { login } from '../services/api.js';
export default { data: () => ({ email: '', password: '', error: '', pendent: false }), methods: {
  async entrar() {
    if (this.pendent) return;
    this.pendent = true; this.error = '';
    try {
      await login(this.email, this.password);
      const dest = this.$route.query.redirect;
      // Només admetem destinacions internes conegudes.
      const safe = typeof dest === 'string' && /^\/(gestio|reptes)(\/|$)/.test(dest);
      await this.$router.replace(safe ? dest : '/reptes');
    } catch (e) { this.error = e.message; }
    finally { this.password = ''; this.pendent = false; }
  }
} };
</script>
