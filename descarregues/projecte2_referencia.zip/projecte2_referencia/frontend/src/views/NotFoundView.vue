<template><h2>Pàgina no trobada</h2><RouterLink to="/reptes">Torna al catàleg</RouterLink></template>
