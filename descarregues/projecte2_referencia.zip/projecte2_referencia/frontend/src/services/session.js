import { reactive } from 'vue';
// Un mòdul compartit menut, sense Vuex ni Pinia. El token desapareix en recarregar.
export const session = reactive({ token: '', user: null });
export function logout() { session.token = ''; session.user = null; }
