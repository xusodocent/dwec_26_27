import { session, logout } from './session.js';
const base = import.meta.env.VITE_API_URL || 'http://localhost:3000';
export async function request(path, { method = 'GET', body, signal, withMeta = false } = {}) {
  let response;
  try {
    response = await fetch(base + path, { method, signal, headers: {
      ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      ...(session.token ? { Authorization: `Bearer ${session.token}` } : {}),
    }, ...(body !== undefined ? { body: JSON.stringify(body) } : {}) });
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new Error('No es pot connectar amb l’API. Comprova json-server.');
  }
  // json-server pot respondre amb objectes, cadenes JSON o text.
  const text = await response.text();
  let data = null;
  if (text) { try { data = JSON.parse(text); } catch { data = text; } }
  if (!response.ok) {
    if (response.status === 401) logout();
    const error = new Error(typeof data === 'string' ? data : data?.missatge || `Error HTTP ${response.status}`);
    error.status = response.status;
    throw error;
  }
  return withMeta ? { data, total: Number(response.headers.get('X-Total-Count') ?? (Array.isArray(data) ? data.length : 0)) } : data;
}
export const reptesApi = {
  // Adaptem el contracte natiu de json-server al que utilitzen les vistes.
  async list({ q = '', categoria = '', ordre = 'nom', pagina = 1, mida = 4 } = {}) {
    const filters = { _sort: ordre, _order: 'asc', _page: pagina, _limit: mida };
    if (q.trim()) filters.q = q.trim();
    if (categoria) filters.categoria = categoria;
    const result = await request('/reptes?' + new URLSearchParams(filters), { withMeta: true });
    return { dades: result.data, total: result.total, pagina: Number(pagina), mida: Number(mida) };
  },
  detail: id => request('/reptes/' + encodeURIComponent(id)),
  create: body => request('/reptes', { method: 'POST', body }),
  replace: (id, body) => request('/reptes/' + encodeURIComponent(id), { method: 'PUT', body }),
  update: (id, body) => request('/reptes/' + encodeURIComponent(id), { method: 'PATCH', body }),
  remove: id => request('/reptes/' + encodeURIComponent(id), { method: 'DELETE' }),
};
// Aquesta lectura protegida valida el token amb el servidor. No hi ha /auth/me.
export async function currentUser() {
  if (!session.user) throw new Error('Cal iniciar sessió');
  const user = await request('/users/' + encodeURIComponent(session.user.id));
  const identity = { id: user.id, email: user.email, rol: user.rol };
  session.user = identity; // No conservem el hash de contrasenya retornat pel fake server.
  return identity;
}
export async function login(email, password) {
  const result = await request('/login', { method: 'POST', body: { email, password } });
  session.token = result.accessToken;
  session.user = { id: result.user.id, email: result.user.email, rol: result.user.rol };
  try { await currentUser(); } catch (error) { logout(); throw error; }
}
