# Comprovacions del material de referència

Validat amb Node 22.22, json-server 0.17.4, json-server-auth 2.1.0 i Chrome.

- Instal·lació neta amb npm ci i inici amb la CLI del complement.
- GET públic, cerca, filtres, ordre i paginació amb X-Total-Count.
- POST/PUT/PATCH/DELETE, conservació de dades i identificador.
- Validació en el client: un formulari invàlid no envia cap POST.
- Petició manual amb dades fora del model: el fake server no valida les regles.
- Login 200, login incorrecte 400, token absent/caducat 401.
- Fitxa pròpia 200, altra fitxa 403 i filtratge del hash en el servei del client.
- Guard: visitant a login, lector a Accés no permés, organitzador a Gestió.
- Token de lector: POST manual 201 sota la regla 664, tal com explica la guia.
- Token caducat facilitat: 401 al servidor i redirecció a login en el client.
- Build del client i de la demo estàtica, i generació de MkDocs.
- Demo: mateixos recorreguts, persistència local, aïllament per navegador,
  restauració de la llavor i enllaç des del menú dels apunts.

Per repetir les proves, segueix la bateria de la setmana 10 de la guia.
No s'ha implementat una política de rols del servidor ni validació de negoci:
aquests aspectes són límits explícits del servidor de desenvolupament.
