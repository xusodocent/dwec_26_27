# La Vall en Joc · Vue, AJAX i json-server

Projecte guiat DWEC de 10 setmanes. Vue 3 Options API, Vue Router 4, fetch i JWT.
Sense Vuex/Pinia ni codi de servidor propi. Node 22.22 o compatible posterior.

## Executar (dos terminals)

Backend: dins de backend, `npm ci`, `npm run reset`, `npm run dev`.
API http://localhost:3000. json-server 0.17.4 + json-server-auth 2.1.0, versions fixades.
No uses latest. db.json es prepara de seed.json i conserva les escriptures.
Per restaurar: para el servidor, guarda còpia i executa `npm run reset -- --confirm`.

Frontend: dins de frontend, `npm ci`, `cp .env.example .env.local`, `npm run dev`.
Client http://localhost:5173. `npm run build` genera dist.

Comptes ficticis: organitza@vall.test / Organitza123! (organitzador)
i lector@vall.test / Lector123! (lector).
El token dura una hora; la sessió en memòria es perd en recarregar.
Logout no revoca tokens copiats. No uses credencials reals.

## Contracte i límits

GET /reptes retorna array; _page/_limit paginen; X-Total-Count informa del total.
Consultes q/categoria/_sort/_order. L'adaptador Vue normalitza la resposta.
POST /login retorna accessToken i user. Login incorrecte: 400.
GET /users/:id valida la sessió i recupera rol; el client descarta el hash de contrasenya.
DELETE /reptes/:id retorna 200 i {} en aquestes versions.
json-server no valida les regles del formulari: la validació és al client.

Els rols de meta.roles protegeixen la NAVEGACIÓ, no les operacions del servidor.
La regla reptes:664 deixa llegir a qualsevol i escriure a qualsevol usuari autenticat.
Per tant, el lector pot enviar POST manual encara que no puga entrar al panell.
users:400 permet llegir la fitxa pròpia i denega les escriptures ordinàries.
No programem registre ni gestió de rols; el complement és de prototipatge local.
El fitxer tokens-prova.json conté un token ja caducat per provar el 401.

Construeix el frontend per fases amb la guia dels apunts. La demo estàtica simula
el mateix contracte en el navegador; la versió d'aquest arxiu usa un servidor HTTP real.
