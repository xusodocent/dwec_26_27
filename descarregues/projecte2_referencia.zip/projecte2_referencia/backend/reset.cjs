// Utilitat de preparació de dades, no és codi d'un servidor.
const { copyFileSync, existsSync } = require('node:fs');
const { join } = require('node:path');
const dest = join(__dirname, 'db.json');
if (existsSync(dest) && !process.argv.includes('--confirm')) {
  console.error('db.json ja existeix. Para el servidor i usa npm run reset -- --confirm per restaurar-lo.');
  process.exit(1);
}
copyFileSync(join(__dirname, 'seed.json'), dest);
console.log('db.json preparat amb les huit proves i dos comptes ficticis.');
