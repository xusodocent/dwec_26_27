# Verificació de la solució

Comprovació feta amb Node.js 22 i Chromium automatitzat amb Playwright.

- Quatre proves automatitzades de regles superades amb `npm test`.
- Huit fitxes inicials i totes les imatges carregades.
- Filtre de fotografia: dues proves. Cerca inexistent: cap resultat.
- Detall obert i tancat amb Escape.
- Un clic repetit no duplica la selecció.
- Tres proves r1, r2 i r3: 75 minuts i 310 punts.
- Ordenació amb botons i drag and drop; ordre conservat en recarregar.
- Formulari invàlid bloquejat, inclosos participants decimals.
- Formulari complet amb itinerari vàlid: justificant local.
- Eliminar una prova d'un itinerari de tres torna a bloquejar la confirmació.
- Bonificació cooperativa: r1, r2 i r4 amb quatre participants, 410 punts.
- Huit marcadors del mapa carregats.
- Callbacks de geolocalització simulats: denegació amb avís i èxit sense duplicar el marcador d'usuari. No es verifica una ubicació física real.
- Cookie de benvinguda creada, llegida després de recarregar i restablida.
- JSON malformat recuperat sense bloqueig; identificadors desconeguts i duplicats descartats.
- Vista d'escriptori de 1440 px i mòbil de 390 px sense desbordament horitzontal.
- Cap excepció JavaScript no capturada durant el recorregut comprovat.

Les captures reals estan en `captures/escriptori.png` i `captures/mobil.png`. La disponibilitat futura de les tessel·les d'OpenStreetMap depén de la connexió i del servei extern.
