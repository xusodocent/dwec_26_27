import { test } from "node:test";
import assert from "node:assert/strict";
import { reptes } from "../js/dades.js";
import { resumir, validarItinerari } from "../js/regles.js";
import { crearModel } from "../js/models.js";
import {
  seleccio,
  afegir,
  moure,
  moureAbans,
  eliminar,
} from "../js/itinerari.js";
const triar = (ids) => ids.map((id) => reptes.find((r) => r.id === id));
test("Catàleg i itinerari inicial", () => {
  assert.equal(reptes.length, 8);
  assert.equal(resumir(reptes).minuts, 245);
  assert.equal(resumir(triar(["r1", "r2", "r3"])).punts, 310);
  assert.deepEqual(validarItinerari(triar(["r1", "r2", "r3"])), []);
  assert.ok(validarItinerari([]).length);
});
test("Límit de 180 minuts i duplicats", () => {
  const r = triar(["r2", "r4", "r5", "r7", "r8"]);
  assert.equal(resumir(r).minuts, 180);
  assert.deepEqual(validarItinerari(r), []);
  assert.ok(
    validarItinerari(
      r.map((v, i) => ({ ...v, minuts: v.minuts + (i === 0 ? 1 : 0) })),
    ).length,
  );
  assert.ok(validarItinerari(triar(["r1", "r1", "r2"])).length);
});
test("Bonificació cooperativa", () => {
  assert.equal(
    triar(["r1", "r2", "r4"])
      .map(crearModel)
      .reduce((s, r) => s + r.calcularPunts(4), 0),
    410,
  );
});
test("Selecció, límit i reordenació", () => {
  seleccio.splice(0);
  ["r1", "r2", "r3", "r4", "r5"].forEach(afegir);
  afegir("r1");
  afegir("r6");
  assert.equal(seleccio.length, 5);
  moure("r1", -1);
  assert.equal(seleccio[0], "r1");
  moureAbans("r5", "r1");
  assert.equal(seleccio[0], "r5");
  eliminar("r5");
  assert.equal(seleccio.length, 4);
  seleccio.splice(0);
});
