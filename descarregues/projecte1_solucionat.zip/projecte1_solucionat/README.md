# La Vall en Joc: solució final

Aplicació de demostració per al projecte de DWEC de 10 setmanes. Inclou HTML, CSS, mòduls JavaScript i quatre imatges generades amb IA, compartides per les dues proves de cada categoria. Les escenes i les ubicacions són fictícies.

## Obrir l'aplicació

Descomprimeix el ZIP i obri la carpeta `projecte1_solucionat` amb VS Code. Pots executar `index.html` amb Live Server.

Alternativament, amb Node.js 18 o posterior, executa des d'aquesta carpeta:

```bash
npm start
```

Obri http://localhost:4173. No cal executar `npm install`. Si el port està ocupat, usa Live Server o configura un altre valor en la variable `PORT`.

Cal un servidor local per als mòduls; no òbrigues l'HTML amb doble clic. El catàleg, la selecció, la validació i les imatges funcionen sense serveis externs. El fons del mapa necessita Internet. La geolocalització requereix localhost o HTTPS i és voluntària. Leaflet 1.9.4 està inclòs amb la seua llicència.

## Demostració de cinc minuts

1. Filtra fotografia: apareixen dues proves. Torna a totes les categories.
2. Consulta el detall i afegeix El codi de la plaça, Memòria del mercat i Perspectives: 75 minuts i 310 punts base.
3. Repeteix un repte: no es duplica. Reordena amb les fletxes o arrossegant una fila davant d'una altra.
4. Recarrega: la selecció i l'ordre es conserven.
5. Completa el formulari amb dades fictícies, modalitat, preferències i acceptació. Confirma per a obtindre un justificant local.
6. Substitueix Perspectives per Relleu cooperatiu: amb quatre participants hi ha 410 punts previstos, però 370 punts base.
7. Consulta el mapa i prova denegar la ubicació: la resta de l'aplicació continua funcionant.

El justificant és una còpia de la selecció confirmada i no canvia en editar l'itinerari. Les dades del formulari no es guarden ni s'envien. La cookie només recorda el tancament de la benvinguda durant set dies. Es pot restablir des del peu de pàgina.

## Organització del codi

`dades.js` conté el catàleg; `regles.js` calcula i valida; `itinerari.js` modifica la selecció; `vista.js` crea nodes; `formulari.js` valida camps; `persistencia.js` gestiona localStorage i cookies; `models.js` implementa la bonificació amb herència; `mapa.js` integra Leaflet; `main.js` connecta dades, vistes i esdeveniments.

Les captures de `captures/` mostren la versió implementada. Els prompts de les imatges estan en `img/PROMPTS.txt`. Les imatges no són fotografies documentals del municipi.

## Verificació

```bash
npm test
```

Aquestes proves comproven càlculs, límits, duplicats, ordenació i bonificació. Consulta `COMPROVACIONS.md` per a la verificació en navegador.
